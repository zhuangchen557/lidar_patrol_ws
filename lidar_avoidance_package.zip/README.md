# lidar_avoidance

一个用于你们巡检车项目的 ROS 2 Jazzy 激光避障测试包。

## 作用

`/scan` -> 判断前方/左右障碍物距离 -> `/cmd_vel`

逻辑：
- 前方 > 1.0 m：0.20 m/s 前进
- 0.50~1.0 m：0.10 m/s 减速
- < 0.50 m：停止前进，并向更空旷的一侧转向

## 注意

这是**避障链路测试包**，不是项目最终的 Nav2 DWB 实现。
你们项目方案指定的最终架构是 Nav2 local_costmap + DWB Controller。
这个包适合先验证 `/scan` 和 `/cmd_vel` 能否打通。

## 安装

把 `lidar_avoidance` 文件夹放进你们 ROS2 工作空间的 `src/`：

```bash
cd ~/lidar_patrol_ws
colcon build --packages-select lidar_avoidance
source install/setup.bash
```

## 运行

先确保雷达已经发布 `/scan`：

```bash
ros2 topic echo /scan
```

然后：

```bash
ros2 launch lidar_avoidance avoidance_test.launch.py
```

检查输出：

```bash
ros2 topic echo /cmd_vel
```

## 重要

测试真实小车前，先把车架空，确认 `/cmd_vel` 数值正确。
最终接入 Nav2 时，不要同时运行这个节点和 DWB Controller 向同一个 `/cmd_vel` 发布，否则两个控制器会抢控制权。
